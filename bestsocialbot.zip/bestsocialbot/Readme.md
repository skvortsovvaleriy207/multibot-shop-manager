# Multibot Shop Manager (BestSocialBot)

Этот проект представляет собой Telegram-бота для управления магазином сообщества, интегрированного с Google Sheets и SQLite.

## 🚀 Как запустить проект

Есть два способа запуска: через Docker (рекомендуется) и локально через Python.

### Предварительные требования

1.  **Токен бота**: Получите токен у [@BotFather](https://t.me/BotFather).
2.  **Google Credentials**: Файл `credentials.json` от сервисного аккаунта Google Cloud с доступом к Google Sheets API.
3.  **Google Таблица**: URL основной таблицы для синхронизации.

### 1️⃣ Настройка конфигурации

Перед запуском скопируйте файл с примером конфигурации (если есть) или создайте `.env` в папке `bestsocialbot`:

```bash
cd bestsocialbot
nano .env
```

Пример содержимого `.env`:
```ini
# Основное
BOT_TOKEN=ваш_токен_бота
ADMIN_ID=ваше_id_telegram
CHANNEL_ID=id_канала_для_постинга

# Google Sheets
CREDENTIALS_FILE=credentials.json
BESTHOME_SURVEY_SHEET_URL=https://docs.google.com/spreadsheets/d/ВАШ_ID_ТАБЛИЦЫ

# Telethon (опционально, для парсинга)
TELETHON_API_ID=ваше_api_id
TELETHON_API_HASH=ваш_api_hash
TELETHON_PHONE_NUMBER=ваш_номер_телефона
```

**Важно:** Файл `credentials.json` должен находиться в папке `bestsocialbot` (или по пути, указанному в переменной `CREDENTIALS_FILE`).

---

### 2️⃣ Запуск через Docker (Рекомендуется)

Убедитесь, что у вас установлены Docker и Docker Compose.

1.  Перейдите в папку с ботом:
    ```bash
    cd bestsocialbot
    ```

2.  Запустите проект:
    ```bash
    docker-compose up --build -d
    ```
    `-d` запускает контейнер в фоновом режиме.

3.  Смотреть логи:
    ```bash
    docker-compose logs -f
    ```

4.  Остановить:
    ```bash
    docker-compose down
    ```

---

### 3️⃣ Локальный запуск (Python)

Требуется Python 3.10+.

1.  Перейдите в папку `bestsocialbot`:
    ```bash
    cd bestsocialbot
    ```

2.  Создайте и активируйте виртуальное окружение:
    ```bash
    python3 -m venv venv
    source venv/bin/activate  # Для Linux/macOS
    # или
    # venv\Scripts\activate   # Для Windows
    ```

3.  Установите зависимости:
    ```bash
    pip install -r requirements.txt
    ```

4.  Запустите бота:
    ```bash
    python main.py
    ```

## 📂 Структура данных

- База данных SQLite сохраняется в файле `bot_database.db`.
- Логи сохраняются в папку `logs`.
- При использовании Docker эти данные сохраняются в volume `besthome_data` и локальной директории (через bind mount).